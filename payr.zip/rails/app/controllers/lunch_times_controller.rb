class LunchTimesController < ApplicationController  
  before_filter :check_user
  before_filter :manager_required, :except => [:index, :show]
  before_filter :retrieve_time, :only => [:edit,:update,:show] 
           
  
  def index    
    @lunch_times = LunchTime.find(:all,
       :conditions => { :employee_id => params[:employee_id]})
  end 
  
  def show; end
  
  def new   
    @lunch_time = LunchTime.new(:employee_id => params[:employee_id])
  end
  
  def edit; end                                                                      
  
  def create
    @lunch_time = LunchTime.new(params[:lunch_time])
    @lunch_time.employee_id = params[:employee_id] 
    @lunch_time.changed_by = current_user.id
    
    if @lunch_time.save
      flash[:notice] = "Lunch time was sucessfully created" 
      redirect_to :action => :show, :id => @lunch_time.id, :employee_id => @employee.id 
    else
      render :action => :new
    end
  end
  
  def update            
    @lunch_time.changed_by = current_user.id
    if @lunch_time.update_attributes(params[:lunch_time])  
      redirect_to :action => :show, :id => @lunch_time.id, :employee_id => @employee.id
    else
      render :action => :edit
    end
  end
  
  protected
  
  def retrieve_time
    @lunch_time = LunchTime.find(params[:id],
      :conditions => { :employee_id => params[:employee_id]})   
  end
end
