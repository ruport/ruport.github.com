# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  
  include ApplicationHelper
  # Pick a unique cookie name to distinguish our session data from others'
  session :session_key => '_payr_session_id'
  
  protected
    def authenticate
      unless session["user"] 
        store_location
        redirect_to :controller => "login" 
        return false
      end
    end     
    
    def manager_required
      unless current_user && current_user.manager?
        flash[:notice] = "Only managers can access that."
        redirect_to "/"                                 
      end
    end           
    
    def check_user                            
      unless current_user.manager? || Integer(params[:employee_id]) == current_user.id 
        redirect_to :controller => :dashboard   
      end            
      @employee = Employee.find(params[:employee_id])   
    end
    
    # Store the URI of the current request (or the provided location argument) in the session.
    #
    # We can return to this location by calling #redirect_back_or_default.
    def store_location(location = request.request_uri)
      location = url_for(location) if Hash === location
      session[:return_to] = location
    end
    
    # Redirect to the URI stored by the most recent store_location call or
    # to the passed default.
    def redirect_back_or_default(default)
      session[:return_to] ? redirect_to(session[:return_to]) : redirect_to(default)
      session[:return_to] = nil
    end 
    
    # (Stolen from Brad Ediger with Love)
    # Convenience method to execute a block of code on the corresponding HTTP verb.
    #
    #   on :post do
    #     puts "Post request"
    #   end
    #
    # is equivalent to:
    #
    #   if request.method == 'post'
    #     puts "Post request"
    #   end
    def on(verb)
      yield if request.method.to_sym == verb
    end
end
