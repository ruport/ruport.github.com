class OtherTimesController < ApplicationController
  
  before_filter :check_user
  
  # GET /other_times
  # GET /other_times.xml
  def index 
    @employee = Employee.find(params[:employee_id])
    @other_times = OtherTime.find(:all)
  end

  # GET /other_times/1
  # GET /other_times/1.xml
  def show
    @other_time = OtherTime.find(params[:id])
  end

  # GET /other_times/new
  def new
    @other_time = OtherTime.new(:employee_id => params[:employee_id])
  end

  # GET /other_times/1;edit
  def edit
    @other_time = OtherTime.find(params[:id], 
      :conditions => {:employee_id => params[:employee_id]})
  end

  # POST /other_times
  # POST /other_times.xml
  def create
    @other_time = OtherTime.new(params[:other_time]) 
    @other_time.employee_id = params[:employee_id]
    @other_time.changed_by = current_user.id   

    if @other_time.save
      flash[:notice] = 'OtherTime was successfully created.'
      redirect_to employee_other_time_path(@other_time.employee_id, @other_time) 
    else
      render :action => "new" 
    end   
  end

  # PUT /other_times/1
  # PUT /other_times/1.xml
  def update
    @other_time = OtherTime.find(params[:id], 
      :conditions => {:employee_id => params[:employee_id]})
    @other_time.changed_by = current_user.id      

    if @other_time.update_attributes(params[:other_time])
      flash[:notice] = 'OtherTime was successfully updated.'
      redirect_to employee_other_time_path(@other_time.employee, @other_time) 
    else
      render :action => "edit" 
    end    
    
  end

  # DELETE /other_times/1
  # DELETE /other_times/1.xml
  def destroy
    @other_time = OtherTime.find(params[:id], 
      :conditions => {:employee_id => params[:employee_id]})
    @other_time.destroy

    redirect_to employee_other_times_path(@employee.id) 
  end
end
