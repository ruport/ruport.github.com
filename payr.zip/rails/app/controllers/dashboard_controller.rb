class DashboardController < ApplicationController 
  before_filter :authenticate
  def index
  end
  
  def clock_in
    on :post do
      current_user.regular_times.create(
        :access_start_address => request.remote_ip,
        :access_time_start => Time.now,
        :start_time => 
          Time.parse("#{params[:hour]}:#{params[:minute]} #{params[:meridian]}"),
        :changed_by => current_user.id
      )
    end
  end
  
  def clock_out
    on :post do
      t = current_user.most_recent_regular_time  
      t.access_end_address = request.remote_ip   
      t.access_time_end = Time.now,
      t.end_time = Time.parse("#{t.start_time.strftime("%m/%d/%Y")} " +
                    "#{params[:hour]}:#{params[:minute]} #{params[:meridian]}")
      t.save!
    end
  end    
  
end
