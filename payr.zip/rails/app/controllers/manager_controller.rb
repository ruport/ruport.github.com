class ManagerController < ApplicationController  
  before_filter :authenticate
  before_filter :manager_required
  
  def index
    
  end
  
end
