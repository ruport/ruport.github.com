class RegularTimesController < ApplicationController     
  before_filter :check_user
  before_filter :manager_required, :except => [:index, :show]
  before_filter :retrieve_time, :only => [:edit,:edit_start_time,:update,:show]
  
  def index    
    @regular_times = RegularTime.find(:all,
       :conditions => { :employee_id => params[:employee_id]})
  end 
  
  def show; end
  
  def new   
    @regular_time = RegularTime.new(:employee_id => params[:employee_id])
  end
  
  def edit; end
  
  def edit_start_time; end                                                                      
  
  def create
    @regular_time = RegularTime.new(params[:regular_time])
    @regular_time.employee_id = params[:employee_id] 
    @regular_time.changed_by = current_user.id
    
    if @regular_time.save
      flash[:notice] = "Regular time was sucessfully created" 
      redirect_to :action => :show, :id => @regular_time.id, :employee_id => @employee.id 
    else
      render :action => :new
    end
  end
  
  def update            
    @regular_time.changed_by = current_user.id
    if @regular_time.update_attributes(params[:regular_time])  
      redirect_to :action => :show, :id => @regular_time.id, :employee_id => @employee.id
    else
      render :action => :edit
    end
  end

  protected 
  
  def retrieve_time
    @regular_time = RegularTime.find(params[:id],
      :conditions => { :employee_id => params[:employee_id]})
  end
end
