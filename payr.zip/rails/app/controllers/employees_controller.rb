class EmployeesController < ApplicationController     
  
  before_filter :authenticate
  before_filter :manager_required, :except => [:reset_password]
  before_filter :retrieve_employee, :only => [:show, :edit, :update]   
  
  def new
    @employee = Employee.new
  end     
  
  def create 
    @employee = Employee.new(params[:employee]) 
    if @employee.save
      flash[:notice] = "Employee was saved sucessfully"   
      redirect_to :controller => "manager"
    else         
      render :action => "new"
    end 
  end
  
  def edit 
  end     
  
  def show
  end
  
  def update                         
    remove_empty_password_fields(params)                   
    if @employee.update_attributes(params[:employee])
      flash[:notice] = "Changes to employee were saved successfully"
      redirect_to :controller => "manager"    
    else
      render :action => "edit"
    end
  end 
  
  def reset_password
    on :post do                          
      current_user.update_attributes!(
        :password              => params[:password],
        :password_confirmation => params[:password_confirmation],
        :password_confirmed    => true)
      redirect_to :controller => "dashboard" 
    end                                      
  rescue
    flash[:notice] = "Passwords do not match"
  end
  
  protected
  
  def retrieve_employee
    @employee = Employee.find(params[:id]) 
  end                                         
  
  def remove_empty_password_fields(params)
    if params[:employee]["password"].blank?   
      params[:employee].delete("password")
    end 
    if params[:employee]["password_confirmation"].blank?
      params[:employee].delete("password_confirmation") 
    end
  end
    
end
