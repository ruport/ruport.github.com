class LoginController < ApplicationController
  def index
    # show login screen
  end

  def login
    if session["user"] = Employee.authenticate(params["name"], params["password"]).id
      redirect_back_or_default("/")
    else
      redirect_to :action => "index" 
    end                             
  rescue Employee::AuthenticationError
    flash[:notice] = "Bad username / password combination"
    redirect_to :action => :index
  end  
  
  def logout(msg="")
    session["user"] = nil
    flash[:notice] = msg
    redirect_to '/' 
  end
end
