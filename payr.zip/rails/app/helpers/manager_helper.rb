module ManagerHelper
  
  def employee_table    
     returning("<h3>Employee Listing</h3>") do |output|
       output << "<table>\n"
       Employee.find(:all, :order => :last_name).each do |r|
         output << "<tr><td>" <<
          "#{link_to r.name, edit_employee_path(r.id)}</td>" <<  
          "<td>#{link_to 'Regular Times', employee_regular_times_path(r.id)}</td>" <<
          "<td>#{link_to 'Lunch Times', employee_lunch_times_path(r.id)}</td>" <<
          "<td>#{link_to 'Other Times', employee_other_times_path(r.id)}</td></tr>"
       end
       output << "</table>"
     end    
  end
  
end
