class Employee < ActiveRecord::Base      
  class AuthenticationError < StandardError; end  
  
  acts_as_reportable        
  
  has_many :regular_times
  has_many :lunch_times
  has_many :other_times
  
  password_changed = lambda { |m| m.password_changed? } 
   
  validates_presence_of :username, :first_name, :last_name
  validates_uniqueness_of :username
  validates_presence_of :password_confirmation, 
                        :if => password_changed
  validates_confirmation_of :password, :if => password_changed  
              

  attr_reader :password

  def password=(pass)     
    @password = pass
    @pass_changed = true  
    salt = [Array.new(6){rand(256).chr}.join].pack("m").chomp
    self.password_salt, self.password_hash =
      salt, Digest::SHA256.hexdigest(pass + salt)
  end
  
  def password_changed?
    @pass_changed
  end 
  
  def self.authenticate(username,password)
    employee = Employee.find(:first, :conditions => { :username => username}) 
    
    if employee.blank? || 
       Digest::SHA256.hexdigest(password + employee.password_salt) !=
       employee.password_hash
          
          raise AuthenticationError, "Username or password invalid" 
          
    end  
    
    employee 
    
  end   
  
  def name
    [first_name, last_name].join(" ")
  end
  
  def most_recent_regular_time
     regular_times.find(:all).sort_by(&:access_time_start).last
  end
  
  def is_clocked_in?
    p = most_recent_regular_time.end_time rescue true
    return !p
  end
   
end
