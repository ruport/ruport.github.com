class RegularTime < ActiveRecord::Base
  acts_as_versioned   
  belongs_to :employee 
  
  def minutes
    if end_time and start_time 
      (end_time - start_time) / 60.0
    else
      0
    end
  end 

  def hours    
    minutes / 60.0
  end  
  
  def self.start_time_for_day(day,options={})
    e = filter_by_day(day, select_by_employee_id(options[:employee])).first        
    e.start_time rescue nil    
  end  
  
  def self.end_time_for_day(day,options={})    
    e = filter_by_day(day, select_by_employee_id(options[:employee])).last         
    e.end_time rescue nil    
  end
  
  def self.select_by_employee_id(eid)
    find(:all, :conditions => [ "employee_id = ?", eid])
  end
  
  private
  
  def self.filter_by_day(day,data)
    data.select { |r| r.start_time.strftime("%Y/%m/%d").eql?(day) }
  end       
end
