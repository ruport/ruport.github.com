class LunchTime < ActiveRecord::Base       
  acts_as_versioned
  belongs_to :employee
end
