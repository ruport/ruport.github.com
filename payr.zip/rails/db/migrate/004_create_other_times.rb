class CreateOtherTimes < ActiveRecord::Migration
  def self.up
    create_table :other_times do |t|
      t.column :employee_id, :integer
      t.column :hours, :float
      t.column :note, :string
      t.column :category, :string
      t.column :date, :datetime
      t.column :version, :integer
      t.column :changed_by, :integer
    end 
    
    OtherTime.create_versioned_table
  end

  def self.down
    drop_table :other_times
    drop_table :other_times_versions
 end 
 
end
