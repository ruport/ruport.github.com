class CreateEmployees < ActiveRecord::Migration
  def self.up
    create_table :employees do |t| 
      t.column :first_name, :string
      t.column :last_name, :string 
      
      t.column :username, :string
      t.column :password_hash, :string
      t.column :password_salt, :string
      t.column :password_confirmed, :boolean, :default => false
      
      t.column :manager, :boolean, :default => false
      
      t.column :start_time, :string, :default => "08:00 AM"
      t.column :lunch_time, :string, :default => "12:00 PM"
      
      t.column :daily_lunch_hours, :float, :default => 0 
      t.column :weekly_regular_hours, :float
      t.column :annual_vacation_hours, :float
      t.column :annual_personal_hours, :float
      t.column :annual_sick_hours, :float
    end
  end

  def self.down
    drop_table :employees
  end
end
