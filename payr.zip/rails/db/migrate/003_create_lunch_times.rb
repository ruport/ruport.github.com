class CreateLunchTimes < ActiveRecord::Migration
  def self.up
    create_table :lunch_times do |t|
      t.column :employee_id, :integer   
      t.column :day, :datetime
      t.column :duration, :float
      t.column :version, :integer   
      t.column :changed_by, :integer
    end                             
    
    LunchTime.create_versioned_table
  end

  def self.down
    drop_table :lunch_times
    drop_table :lunch_times_versions  
  end
end
