class CreateRegularTimes < ActiveRecord::Migration
  def self.up
    create_table :regular_times do |t|
      t.column :employee_id, :integer   
      t.column :access_time_start, :datetime
      t.column :access_time_end,  :datetime    
      t.column :access_start_address, :string
      t.column :access_end_address, :string
      t.column :start_time, :datetime
      t.column :end_time, :datetime  
      t.column :version, :integer   
      t.column :changed_by, :integer
    end                             
    
    RegularTime.create_versioned_table
  end

  def self.down
    drop_table :regular_times
  end
end
