require File.dirname(__FILE__) + '/../test_helper'
require 'employees_controller'

# Re-raise errors caught by the controller.
class EmployeesController; def rescue_action(e) raise e end; end

class EmployeesControllerTest < Test::Unit::TestCase
  def setup
    @controller = EmployeesController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
    
    @e = Employee.create(:username => "gibson", 
                    :password => "gsgi",
                    :password_confirmation => "gsgi", 
                    :first_name => "Gregory",
                    :last_name  => "Gibson" )
  end
  
  def test_reset_password  
    
    get :reset_password, {}, { "user" => @e.id }
    assert_response :success     
    assert !@e.password_confirmed?   
    post :reset_password, {:password => "kitten",
                           :password_confirmation => "kitten"}, 
                          { "user" => @e.id}    
    assert_redirected_to :controller => "dashboard"
    
    assert_equal @e, Employee.authenticate("gibson","kitten")             
  end  
  
end
