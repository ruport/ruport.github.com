require File.dirname(__FILE__) + '/../test_helper'
require 'other_times_controller'

# Re-raise errors caught by the controller.
class OtherTimesController; def rescue_action(e) raise e end; end

class OtherTimesControllerTest < Test::Unit::TestCase

  def setup
    @controller = OtherTimesController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end         
  
  def test_nothing
    assert true
  end


end
