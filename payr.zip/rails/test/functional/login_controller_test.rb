require File.dirname(__FILE__) + '/../test_helper'
require 'login_controller'

# Re-raise errors caught by the controller.
class LoginController; def rescue_action(e) raise e end; end

class LoginControllerTest < Test::Unit::TestCase
  def setup
    @controller = LoginController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
    
    Employee.create(:username => "gibson", 
                    :password => "gsgi",
                    :password_confirmation => "gsgi", 
                    :first_name => "Gregory",
                    :last_name  => "Gibson" )
  end

  # Replace this with your real tests.
  def test_index
    get :index
    assert_response :success
  end
     
  def test_login                                       
    login
    assert_redirected_to "/"  
                 
    e = Employee.find_by_username("gibson")
    assert_logged_in_as(e) 
  end      
  
  def test_logout
    login
    get :logout
    assert_not_logged_in
  end
  
  def login
    post :login, :name => "gibson", :password => "gsgi"    
  end
  
  def assert_logged_in_as(employee)
    assert_block do    
      session["user"] == employee.id     
    end
  end                   
  
  def assert_not_logged_in
    assert_block { session["user"].nil? }
  end
  
end
