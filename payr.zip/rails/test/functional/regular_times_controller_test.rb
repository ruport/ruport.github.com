require File.dirname(__FILE__) + '/../test_helper'
require 'regular_times_controller'

# Re-raise errors caught by the controller.
class RegularTimesController; def rescue_action(e) raise e end; end

class RegularTimesControllerTest < Test::Unit::TestCase
  def setup
    @controller = RegularTimesController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
