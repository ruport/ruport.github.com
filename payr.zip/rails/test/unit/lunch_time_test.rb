require File.dirname(__FILE__) + '/../test_helper'

class LunchTimeTest < Test::Unit::TestCase
  fixtures :lunch_times

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
