require File.dirname(__FILE__) + '/../test_helper'

class EmployeeTest < Test::Unit::TestCase
  
  context "when creating users" do  
    
    def setup
      @e = Employee.new(:username => "sandal", :first_name => "Gregory",
                                               :last_name  => "Brown" )
    end
  
    def specify_employee_password_confirmation_must_be_set
      @e.password = "apples"
      @e.save
      assert !@e.valid?
      assert @e.errors.invalid?(:password_confirmation),
         "Does not make sure password_confirmation is present"    
    end   
    
    def specify_password_confirmation_must_be_same_as_password
      @e.password = "apples"
      @e.password_confirmation = "kittens"
      @e.save
      
      assert !@e.valid?
      assert @e.errors.invalid?(:password),
          "Does not ensure password and password_confirmation are the same"  
    end
    
    def specify_password_confirmation_succeeds_when_same_as_password 
      confirm_password_and_save 
      assert @e.valid?
    end 
    
    def specify_password_confirmation_not_needed_when_password_is_not_changed
      confirm_password_and_save
      assert @e.valid?
       
      e = Employee.find_by_username("sandal") 
      e.first_name = "Groucho"
      e.save
      
      assert e.valid?
    end
    
  end  
  
  context "when authenticating users" do
    
    def setup
      @e = Employee.new(:username => "sandal", :first_name => "Gregory",
                                               :last_name  => "Brown" )
      confirm_password_and_save
    end
    
    def specify_user_name_should_be_unique
      e2 = Employee.create(:username => "sandal")
      assert !e2.valid?
      assert e2.errors.invalid?(:username), 
        "Validations should ensure no duplicate usernames" 
    end 
    
    def specify_should_raise_on_incorrect_login
      assert_raises(Employee::AuthenticationError) { 
        Employee.authenticate("sand","apple")
      }
    end         
    
    def specify_should_raise_on_incorrect_password
      assert_raises(Employee::AuthenticationError) {
        Employee.authenticate("sandal","kitten")
      }
    end
    
    def specify_should_return_user_when_given_valid_login_and_password
       assert_equal @e, Employee.authenticate("sandal","apple")
    end
    
  end                
  
  def confirm_password_and_save
    @e.password = "apple"
    @e.password_confirmation = "apple"
    @e.save
  end
end
