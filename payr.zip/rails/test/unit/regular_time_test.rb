require File.dirname(__FILE__) + '/../test_helper'

class RegularTimeTest < Test::Unit::TestCase
  fixtures :regular_times

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
