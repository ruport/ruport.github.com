require "templates"

class TimeSheetRenderer < Ruport::Renderer
  
end

class CallInRenderer < Ruport::Renderer
   
  stage :call_in_sheet     
  
  def setup
    self.data = CallInAggregator(:start => options[:start_date]) 
  end                                
  
  module Helpers
    def start_date
      options.start_date.strftime("%m/%d/%Y") 
    end
    
    def end_date
      (options.start_date + 13.days).strftime("%m/%d/%Y")
    end
  end
  
  class PDF < Ruport::Formatter::PDF
    
    renders :pdf, :for => CallInRenderer
       
    def build_call_in_sheet
      pad_bottom(10) do
        add_text "Call In Sheet (#{start_date} - #{end_date})" 
      end                                                      
      render_grouping data, options.to_hash.merge(:formatter => pdf_writer)       
    end
    
  end        
  
  class HTML < Ruport::Formatter::HTML
    
    renders :html, :for => CallInRenderer
    
    def build_call_in_sheet
      output << textile("h3. Call In Sheet (#{start_date} - #{end_date})")   
      output << data.to_html(:style => :justified)
    end
    
  end
  
end      

def CallInAggregator(options={}) 
  CallInAggregator.new(options).to_grouping
end

class TimeSheetAggregator
   def initialize(options={})
      @start = options[:start]
      times = RegularTime.find(:all,
        :conditions => ["start_time between ? and ?", @start, @start + 14.days ] ) 
      
      @regular_times = times.group_by { |e| e.start_time.beginning_of_day }
      
      week1, week2 = @regular_times.partition { |d,_| d < @start + 7.days }
      
      @week1_data = time_data_for_week(week1,@start)
      @week2_data = time_data_for_week(week2,@start + 7.days)  
      
      p @week1_data  
   end                         
   
   def time_data_for_week(week_data,start)   
     
     data = {} 
     
     %w[M T W TH F S].zip((0..6).to_a).each do |day,offset|       
       d = week_data.find { |d,_| d == start + offset.days }
       next unless d
       d = d[-1]
       data[day] = { 
         :regular_hours => d.inject(0) do |s,e| 
           s + (e.end_time ? (e.end_time - e.start_time) / 3600 : 0)
         end,
         :start_time => d.map { |e| e.start_time }.sort[0],
         :end_time   => d.map { |e| e.end_time }.sort[-1]#,
         #:lunch_hours => 
       }
     end  
     
     return data
   end
   
end

class CallInAggregator           
  
  def initialize(options={})
    @start = options[:start]    
  end
  
  def to_grouping
    table = Table([:employee_type, :employee, :week1, :week2, :regular_hours, :overtime, :lunch, 
           :personal, :sick, :vacation ]) do |t|
      Employee.find(:all).map(&:id).each do |eid|
        t << employee_record(eid)
      end
    end     
    table.rename_columns(:week1 => "Week 1",
                         :week2 => "Week 2")  
    table.rename_columns { |c| c.to_s.titleize }
    
    Grouping(table,:by => "Employee Type")
  end   
  
  def employee_record(employee_id)
     record = {} 
     
     employee = Employee.find(employee_id)  
     
     regular_times = RegularTime.find(:all, 
       :conditions => ["employee_id = ? and start_time between ? and ?",
                        employee_id, @start, @start + 14.days] )
     
     week1, week2 = 
       regular_times.group_by { |r| r.start_time.beginning_of_week }.
                     sort.map { |e| e[-1].inject(0) { |s,e| s + e.hours } }
     
     overtime = (week1 + week2) - 
       ((employee.weekly_regular_hours || 40) * 2)
          
     overtime = 0 if overtime < 0 
     
     lunch = LunchTime.find(:all, 
       :conditions => ["employee_id = ? and day between ? and ?",
                       employee_id, @start, @start + 14.days] ).inject(0) {|s,e|
       s + e.duration
     }     
     
     personal, sick, vacation = %w[Personal Sick Vacation].map { |cat|
       OtherTime.find(:all, 
         :conditions => ["employee_id = ? and category = ? and date between ? and ?",
                        employee_id, cat, @start, @start + 14.days ]).inject(0) { |s,e|
         s + e.hours 
       }
     }    
     
     record[:week1] = week1
     record[:week2] = week2      
     record[:regular_hours] = week1 + week2
     record[:overtime] = overtime
     record[:lunch] = lunch
     record[:personal] = personal
     record[:sick] = sick
     record[:vacation] = vacation
     record[:employee] = employee.name 
     record[:employee_type] = employee.group
     
     return record
  end
  
end