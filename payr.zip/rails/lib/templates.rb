Ruport::Formatter::Template.create(:standard) do |t|
  
  t.page_format = {
    :layout => :landscape
  }            
            
  t.grouping_format = {
    :style => :separated
  }
                       
  t.text_format = {
    :font_size => 16,
    :justification => :center
  }                         
  
  t.table_format = {
    :font_size         => 10,
    :heading_font_size => 10,
    :maximum_width     => 720,
    :width             => 720
  }                          
  
  t.column_format = {
    :alignment => :right
  }                         
  
  t.heading_format = {
    :alignment => :right,
    :bold      => true
  }                   
  
end